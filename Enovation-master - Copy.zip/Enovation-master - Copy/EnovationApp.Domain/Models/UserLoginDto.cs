﻿namespace EnovationAssignment.Models
{
    public class UserLoginDto
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}
